package com.example.thigk2truonganhbinh;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ActivityCN2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cn2);


        EditText edtT = findViewById(R.id.edtT);
        EditText edtN = findViewById(R.id.edtN);
        TextView tvKQ = findViewById(R.id.tvKQ);
        Button btnKT = findViewById(R.id.btnKT);

        btnKT.setOnClickListener(v -> {

        });
    }
}